import styles from './TemplateName.module.scss';

interface TemplateNameProps{}

export const TemplateName = ({}: TemplateNameProps)=>{

  return(
    <div className={styles.templateName}>
        TemplateName Component
    </div>
  )
};