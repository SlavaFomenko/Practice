import React, { Component } from 'react';
import { ThemeContext, UserContext } from '../../../context';

class User extends Component {
  render() {
    return (
      <ThemeContext.Consumer>
        {
          (theme) => (
            <UserContext.Consumer>
              {
                (user) => (
                  <sections>
                    <p>Ivan Ivanov, THEME:{theme}, Status:{user.status}</p>
                  </sections>
                )
              }
            </UserContext.Consumer>
          )
        }
      </ThemeContext.Consumer>

    );
  }
}

export default User;
