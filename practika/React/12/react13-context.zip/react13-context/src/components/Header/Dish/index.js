import React, { Component, useContext } from 'react';
import { ThemeContext } from '../../../context';


class Dish extends Component {
  render() {
    const { name } = this.props;
    // const theme = this.context.theme
    console.log(this.context.theme);
    return (
      <div>
        Dish: {name}, Theme: {this.context.theme}
      </div>
    );
  }
}
Dish.contextType = ThemeContext;

export default Dish;
