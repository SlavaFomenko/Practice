export interface InfoItemProps {
    icon: React.ReactNode,
    text: string | null,
    isLink?: boolean
}